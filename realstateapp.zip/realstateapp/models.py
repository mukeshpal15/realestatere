from django.db import models
from datetime import datetime, date
from django.conf import settings
TIME_FORMAT = '%d.%m.%Y'
class PropertyCategoryData(models.Model):
	Category_ID=models.CharField(max_length=100)
	Category_Name=models.CharField(max_length=50)
	Category_Image=models.ImageField(upload_to="categoryimages/")
	class Meta:
		db_table="PropertyCategoryData"

class PropertyData(models.Model):
	Property_ID=models.CharField(max_length=100)
	Property_Name=models.CharField(max_length=100)
	Property_About=models.CharField(max_length=1000)
	Property_Address=models.CharField(max_length=1000)
	Property_Area=models.CharField(max_length=1000)
	Property_Beds=models.CharField(max_length=50, default='NA')
	Property_Baths=models.CharField(max_length=50, default='NA')
	Property_Garages=models.CharField(max_length=50, default='NA')
	Property_Price=models.CharField(max_length=50)
	Property_Category=models.CharField(max_length=100)
	Property_Streat=models.CharField(max_length=50, default='NA')
	Property_Direction=models.CharField(max_length=100)
	property_Facility= models.TextField()
	property_Diversion=models.CharField(max_length=100)
	Property_BuiltYear=models.CharField(max_length=50, default='NA')
	Property_status=models.CharField(max_length=50, default='FOR SALE')
	Property_location=models.CharField(max_length=100)
	class Meta:
		db_table="PropertyData"

class PropertyImagesData(models.Model):
	Property_ID=models.CharField(max_length=100)
	Property_Image=models.ImageField(upload_to="propertyimages/")
	class Meta:
		db_table="PropertyImagesData"

class agent_account(models.Model):
	agent_id=models.CharField(max_length=20)
	name=models.CharField(max_length=40)
	gender=models.CharField(max_length=10)
	email=models.CharField(max_length=50)
	address=models.CharField(max_length=400)
	city=models.CharField(max_length=20)
	phone=models.CharField(max_length=15)
	aadhar=models.CharField(max_length=16)
	password=models.CharField(max_length=40)
	facebook=models.CharField(max_length=150, default='NA')
	twitter=models.CharField(max_length=150, default='NA')
	linkedin=models.CharField(max_length=150, default='NA')
	status = models.CharField(max_length=10)
	agentpic=models.ImageField(upload_to='agentpic')
	class Meta:
		db_table="agent_account"

class user_account(models.Model):
	user_id=models.CharField(max_length=20)
	name=models.CharField(max_length=40)
	gender=models.CharField(max_length=10)
	email=models.CharField(max_length=50)
	address=models.CharField(max_length=400)
	city=models.CharField(max_length=20)
	phone=models.CharField(max_length=15)
	password=models.CharField(max_length=40)
	userpic=models.ImageField(upload_to="userpic/" ,blank=True)
	class Meta:
		db_table="user_account"

class myaccount(models.Model):
	name = models.CharField(max_length=10)
	pic = models.ImageField(upload_to='pic')
	class Meta:
		db_table="myaccount"

class blog_table(models.Model):
	agent_id = models.CharField(max_length=20)
	blog_no = models.CharField(max_length=50)
	pic_of_pro =models.ImageField(upload_to='blog_pic')
	date = models.DateField(auto_now=True)
	subject = models.CharField(max_length=60, default='')
	Desc = models.TextField()
	class Meta:
		db_table="blog_table"
	

class OrderData(models.Model):
	Order_ID=models.CharField(max_length=100)
	Order_Date=models.DateField(auto_now=True)
	Property_ID=models.CharField(max_length=100)
	Property_Name=models.CharField(max_length=100)
	Buyer_ID=models.CharField(max_length=100)
	Payment_ID=models.CharField(max_length=100, blank=True)
	Order_Status=models.CharField(max_length=100)
	Total_Amount=models.CharField(max_length=100)
	Amount_to_Pay=models.CharField(max_length=100)
	class Meta:
		db_table="OrderData"

class CartData(models.Model):
	Cart_ID=models.CharField(max_length=100)
	Order_ID=models.CharField(max_length=50)
	Email=models.CharField(max_length=100)
	Buyer_ID=models.CharField(max_length=100)
	class Meta:
		db_table="CartData"		
			

class mapapproval(models.Model):
	date=models.DateTimeField()
	Property_ID=models.CharField(max_length=100)
	Buyer_ID=models.CharField(max_length=100)
	Land_Paper=models.FileField(upload_to="map_approval/")
	Map_by_engineer=models.ImageField(upload_to="map_by_engineer/") 
	Copy_of_Tax=models.FileField(upload_to="map_approval/")
	other_details=models.TextField(default='')
	map_approved=models.ImageField(upload_to="aproved_map/", default='')
	class Meta:
		db_table="mapapproval"

class Loandetails(models.Model):
	date=models.DateTimeField()
	datetime = models.DateTimeField(auto_now=True)
	loan_id=models.CharField(max_length=100)
	Loan_Type=models.CharField(max_length=100)
	Name=models.CharField(max_length=100)
	Email_ID=models.CharField(max_length=100)
	Phone=models.CharField(max_length=100)
	City=models.CharField(max_length=100)
	State=models.CharField(max_length=100)
	DOB=models.CharField(max_length=100)
	employee=models.CharField(max_length=100)
	Income=models.CharField(max_length=100)
	Loan_Required=models.CharField(max_length=100)
	class Meta:
		db_table="Loandetails"


		