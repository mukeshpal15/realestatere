from django.apps import AppConfig


class RealstateappConfig(AppConfig):
    name = 'realstateapp'
